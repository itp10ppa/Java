package ru.Sukmanova.Main;

import ru.Sukmanova.Birds.*;
import ru.Sukmanova.City.*;
import ru.Sukmanova.Points.*;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;
import static java.lang.Integer.parseInt;
import static java.lang.Math.pow;


public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("\n-- Выбор задания --");
        System.out.println(" 1 - Задание 1.10");
        System.out.println(" 2 - Задание 2.5");
        System.out.println(" 3 - Задание 3.3");
        System.out.println(" 4 - Задание 3.5");
        System.out.println(" 5 - Задание 4.3");
        System.out.println(" 6 - Задание 5.9");
        System.out.println(" 7 - Задание 6.5");
        System.out.println(" 8 - Задание 7.3");
        System.out.println(" 9 - Задание 8.4");
        System.out.println("-------");
        System.out.print("Введите номер: ");

        int choice = sc.nextInt();
        sc.nextLine(); // очистка буфера после nextInt()
        System.out.println();

        switch (choice) {
            case 1 -> task110(sc);
            case 2 -> task25(sc);
            case 3 -> task33(sc);
            case 4 -> task35(sc);
            case 5 -> task43(sc);
            case 6 -> task59(sc);
            case 7 -> task65(sc);
            case 8 -> System.out.println(task73(args[0], args[1]));
            case 9 -> task84(sc);
            default -> System.out.println("Нет такого задания");
        }
        sc.close();
    }

    // Создать метод возведения в степень с использованием статического импорта и аргументов командной строки.
    static double task73(String x, String y) {
        return pow(parseInt(x), parseInt(y));
        // java -cp "out\production\Lab 3" ru.Sukmanova.Main.Main 2 4
    }

    static void printCities(List<City> cities) {
        System.out.println("-- Схема --");
        for (City city : cities) {
            System.out.println(city);
        }
    }

    static void runCityMenu(Scanner sc, List<City> cities) {
        while (true) {
            System.out.println("\n-- МЕНЮ --");
            System.out.println(" 1 - Показать все города и пути");
            System.out.println(" 2 - Добавить город");
            System.out.println(" 3 - Добавить путь");
            System.out.println(" 4 - Удалить путь");
            System.out.println(" 0 - Выход");
            System.out.println("-------");
            System.out.print("Введите номер: ");

            int choice = -1;
            while (choice < 0 || choice > 4) {
                if (sc.hasNextInt()) {
                    choice = sc.nextInt();
                    sc.nextLine();
                    if (choice < 0 || choice > 4) {
                        System.out.print("Число от 0 до 4! Повторите: ");
                    }
                } else {
                    System.out.print("Это не число! Повторите: ");
                    sc.nextLine();
                }
            }
            System.out.println();

            if (choice == 1) {
                printCities(cities);
            }
            else if (choice == 2) {
                System.out.println("-- Добавление города --");

                System.out.print("Введите название города: ");
                String name = sc.nextLine().trim();

                boolean flag = true;
                for (City city : cities) {
                    if (city.getName().equalsIgnoreCase(name)) {
                        flag = false;
                        break;
                    }
                }
                if (name.isEmpty()) {
                    System.out.println("Название не может быть пустым!");
                }
                else if (!flag) {
                    System.out.println("Город " + name + " уже существует!");
                }
                else {
                    City newCity;
                    if (!cities.isEmpty() && cities.get(0) instanceof MutualCity) {
                        newCity = new MutualCity(name);
                    } else {
                        newCity = new City(name);
                    }
                    cities.add(newCity);
                    System.out.println("Город " + name + " добавлен.");
                }
            }
            else if (choice == 3) {
                System.out.println("-- Добавление пути --");

                System.out.print("Из какого города? ");
                String fromName = sc.nextLine().trim();

                City from = null;
                for (City city : cities) {
                    if (city.getName().equalsIgnoreCase(fromName)) {
                        from = city;
                    }
                }
                if (from == null) {
                    System.out.println("Города " + fromName + " нет в списке!");
                    continue;
                }

                System.out.print("В какой город? ");
                String toName = sc.nextLine().trim();

                City to = null;
                for (City city : cities) {
                    if (city.getName().equalsIgnoreCase(toName)) {
                        to = city;
                    }
                }
                if (to == null) {
                    System.out.println("Города " + toName + " нет в списке!");
                    continue;
                }
                int price = -1;
                while (price < 0) {
                    System.out.print("Цена: ");
                    if (sc.hasNextInt()) {
                        price = sc.nextInt();
                        sc.nextLine();
                        if (price < 0) {
                            System.out.println("Цена не может быть отрицательной!");
                        }
                    } else {
                        System.out.println("Это не число!");
                        sc.nextLine();
                    }
                }
                try {
                    from.addPath(to, price);
                    System.out.println("Путь " + fromName + " -> " + toName + " за " + price + " добавлен.");
                }
                catch (IllegalArgumentException ex) {
                    System.out.println("Ошибка: " + ex.getMessage());
                }
            }
            else if (choice == 4) {
                System.out.println("-- Удаление пути --");

                System.out.print("Из какого города? ");
                String fromName = sc.nextLine().trim();

                City from = null;
                for (City city : cities) {
                    if (city.getName().equalsIgnoreCase(fromName)) {
                        from = city;
                    }
                }
                if (from == null) {
                    System.out.println("Города " + fromName + " нет в списке!");
                    continue;
                }

                System.out.print("В какой город? ");
                String toName = sc.nextLine().trim();

                City to = null;
                for (City city : cities) {
                    if (city.getName().equalsIgnoreCase(toName)) {
                        to = city;
                    }
                }
                if (to == null) {
                    System.out.println("Города " + toName + " нет в списке!");
                    continue;
                }
                from.removePath(to);
            }
            else {
                System.out.println("Выход. Завершение работы...");
                return;
            }
        }
    }

    static List<City> buildCities() {
        City a = new City("A");
        City b = new City("B");
        City c = new City("C");
        City d = new City("D");
        City e = new City("E");
        City f = new City("F");

        a.addPath(b, 5);
        a.addPath(d, 6);
        a.addPath(f, 1);
        b.addPath(a, 5);
        b.addPath(c, 3);
        c.addPath(b, 3);
        c.addPath(d, 4);
        d.addPath(a, 6);
        d.addPath(c, 4);
        d.addPath(e, 2);
        e.addPath(f, 2);
        f.addPath(b, 1);
        f.addPath(e, 2);

        List<City> cities = new ArrayList<>();
        cities.add(a);
        cities.add(b);
        cities.add(c);
        cities.add(d);
        cities.add(e);
        cities.add(f);
        return cities;
    }

    // Гарантировать, что между двумя городами может быть только одна прямая дорога, и реализовать
    // методы добавления/удаления путей.
    static void task110(Scanner sc) {
        List<City> cities = buildCities();
        runCityMenu(sc, cities);
    }

    // Разработать сущность «Маршрут» с началом и концом, которая умеет находить путь между городами
    // и возвращать его массивом или строкой.
    static void task25(Scanner sc) {
        List<City> c = buildCities();
        City z = new City("Z");

        System.out.println("Из F в D: " + new Route(c.get(5), c.get(3)));
        System.out.println("Из A в C: " + new Route(c.get(0), c.get(2)));
        System.out.println("Из B в Z: " + new Route(c.get(1), z));

        City[] route = new Route(c.get(5), c.get(3)).getRoute();
        System.out.println("Массив: " + java.util.Arrays.toString(route));
    }

    // Разработать сущность «Маршрут» с началом и концом, которая умеет находить путь между городами
    // и возвращать его массивом или строкой.
    static void task33(Scanner sc) {
        List<City> cities = new ArrayList<>();
        System.out.println("Вводите города (0 — закончить):");

        while (true) {
            System.out.print("\nНазвание города: ");
            String name = sc.nextLine().trim();

            if (name.equals("0")) {
                break;
            }
            if (name.isEmpty()) {
                System.out.println("Название не может быть пустым!");
                continue;
            }

            boolean exists = false;
            for (City city : cities) {
                if (city.getName().equalsIgnoreCase(name)) {
                    exists = true;
                    break;
                }
            }
            if (exists) {
                System.out.println("Город " + name + " уже есть!");
            }
            else {
                cities.add(new MutualCity(name));
                System.out.println("Город " + name + " добавлен.");
            }
        }
        runCityMenu(sc, cities);
    }


    static int readInt(Scanner sc, String text) {
        while (true) {
            System.out.print(text);
            if (sc.hasNextInt()) {
                int value = sc.nextInt();
                sc.nextLine();
                return value;
            }
            else {
                System.out.println("Это не число! Повторите.");
                sc.nextLine();
            }
        }
    }

    // Создать подвид двумерной точки, который имеет три координаты (X, Y, Z).
    static void task35(Scanner sc) {
        int count = readInt(sc, "Введите кол-во точек: ");
        Point3D[] points = new Point3D[count];

        for (int i = 0; i < count; i++) {
            System.out.println("\nТочка " + (i + 1) + ":");
            int x = readInt(sc, " x = ");
            int y = readInt(sc, " y = ");
            int z = readInt(sc, " z = ");
            points[i] = new Point3D(x, y, z);
        }

        System.out.println("\n-- Введённые точки --");
        for (Point3D p : points) {
            System.out.println(p);
        }
    }

    // Создать абстрактный класс «Птица» и реализовать трех наследников с их уникальным поведением пения.
    static void task43(Scanner sc) {
        List<Bird> birds = new ArrayList<>();

        while (true) {
            System.out.println("\n-- Создать птичку --");
            System.out.println("1 - Воробей");
            System.out.println("2 - Кукушка");
            System.out.println("3 - Попугай");
            System.out.println("0 - Послушать пение");
            System.out.print("Выбор: ");

            int choice = -1;
            while (choice < 0 || choice > 3) {
                if (sc.hasNextInt()) {
                    choice = sc.nextInt();
                    sc.nextLine();
                    if (choice < 0 || choice > 3) {
                        System.out.print("Число от 0 до 3! Попробуйте еще раз: ");
                    }
                } else {
                    System.out.print("Это не число! Попробуйте еще раз: ");
                    sc.nextLine();
                }
            }

            if (choice == 1) {
                birds.add(new Sparrow());
            }
            else if (choice == 2) {
                birds.add(new Cuckoo());
            }
            else if (choice == 3) {
                System.out.print("Текст попугая: ");
                String text = sc.nextLine().trim();
                if (text.isEmpty()) {
                    System.out.println("Текст не может быть пустым!");
                }
                else {
                    birds.add(new Parrot(text));
                }
            }
            else {
                break;
            }
        }
        System.out.println("\n-- Все птицы поют --");
        for (Bird bird : birds) {
            System.out.print(bird + ": ");
            bird.sing();
        }
    }

    // Реализовать конкретный граф, используя в одной программе и односторонние, и двусторонние дороги.
    static void task59(Scanner sc) {
        List<City> cities = new ArrayList<>();

        MutualCity a = new MutualCity("A");
        City b = new City("B");
        MutualCity c = new MutualCity("C");
        MutualCity d = new MutualCity("D");
        City e = new City("E");

        cities.add(a);
        cities.add(b);
        cities.add(c);
        cities.add(d);
        cities.add(e);

        a.addPath(b, 5);
        a.addPath(c, 7);
        d.addPath(b, 3);
        d.addPath(e, 4);
        b.addPath(c, 2);
        e.addPath(c, 6);

        printCities(cities);
    }

    // Переопределить метод сравнения городов так, чтобы они считались равными при одинаковом наборе путей.
    static void task65(Scanner sc) {
        List<City> cities = new ArrayList<>();
        City a = new City("A");
        City b = new City("B");
        City c = new City("C");
        City d = new City("D");

        a.addPath(b, 5);
        a.addPath(c, 10);

        d.addPath(b, 5);
        d.addPath(c, 10);

        MutualCity m = new MutualCity("M");
        m.addPath(b, 5);
        m.addPath(c, 10);

        cities.add(a);
        cities.add(b);
        cities.add(c);
        cities.add(d);
        cities.add(m);
        printCities(cities);

        System.out.println("\n-- Результат --");
        System.out.println("A = D: " + a.equals(d));
        System.out.println("A = M: " + a.equals(m));
        System.out.println("A = A: " + a.equals(a));
        System.out.println("A = B: " + a.equals(b));
    }

    // Переопределить метод клонирования у сущности «Точка», чтобы он возвращал новую независимую
    // копию с теми же значениями полей.
    static void task84(Scanner sc) {
        Point p1 = new Point(3, 5);
        Point p2 = p1.clone();

        System.out.println("Первая точка p1 = " + p1);
        System.out.println("Вторая точка (клон) p2 = " + p2);
        System.out.println("p1 == p2? - " + (p1 == p2));

        System.out.println("Изменим значение X у точки p2 на 100.");
        p2.setX(100);
        System.out.println("Первая точка p1 = " + p1);
        System.out.println("Вторая точка (клон) p2 = " + p2);
    }
}
