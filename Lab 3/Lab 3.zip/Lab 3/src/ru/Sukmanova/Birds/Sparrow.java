package ru.Sukmanova.Birds;

public class Sparrow extends Bird {

    @Override
    public void sing() {
        System.out.println("Чырык");
    }

    @Override
    public String toString() {
        return "Воробей";
    }
}
