package ru.Sukmanova.Birds;

public class Cuckoo extends Bird {

    @Override
    public void sing() {
        int count = 1 + (int)(Math.random() * 10);
        for (int i = 0; i < count; i++) {
            System.out.print("Ку-ку ");
        }
    }

    @Override
    public String toString() {
        return "\nКукушка";
    }
}
