package ru.Sukmanova.Birds;

public abstract class Bird {

    public abstract void sing();

    @Override
    public String toString() {
        return "Птица";
    }
}
