package ru.Sukmanova.Birds;

public class Parrot extends Bird {

    private String text;

    public Parrot(String text) {
        if (text == null || text.isEmpty()) {
            throw new IllegalArgumentException("Текст не может быть пустым!");
        }
        this.text = text;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        if (text == null || text.isEmpty()) {
            throw new IllegalArgumentException("Текст не может быть пустым!");
        }
        this.text = text;
    }

    @Override
    public void sing() {
        int n = 1 + (int)(Math.random() * text.length());
        System.out.println(text.substring(0, n));
    }

    @Override
    public String toString() {
        return "Попугай (\"" + text + "\")";
    }
}