package ru.Sukmanova.City;

public class Path {

    public City destination;
    public int price;

    public Path(City destination, int price) {
        this.destination = destination;
        this.price = price;
    }

    @Override
    public String toString() {
        return destination.getName() + ":" + price;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Path other)) {
            return false;
        }
        return this.price == other.price && this.destination.getName().equals(other.destination.getName());
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(price, destination.getName());
    }
}
