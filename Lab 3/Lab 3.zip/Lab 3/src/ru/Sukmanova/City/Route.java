package ru.Sukmanova.City;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;


public class Route {

    private City start;
    private City end;

    public Route(City start, City end) {
        setStart(start);
        setEnd(end);
    }

    public City getStart() {
        return start;
    }

    public City getEnd() {
        return end;
    }

    public void setStart(City start) {
        if (start == null) {
            throw new IllegalArgumentException("Ошибка: Город отправления не может быть NULL!");
        }
        this.start = start;
    }

    public void setEnd(City end) {
        if (end == null) {
            throw new IllegalArgumentException("Ошибка: Город назначения не может быть NULL!");
        }
        this.end = end;
    }

    @Override
    public String toString() {
        City[] route = getRoute();
        if (route.length == 0) {
            return "Маршрут не найден";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < route.length; i++) {
            if (i > 0) sb.append(" -> ");
            sb.append(route[i].getName());
        }
        return sb.toString();
    }

    public City[] getRoute() {
        List<City> path = new ArrayList<>();
        Set<City> visited = new HashSet<>();

        if (findPath(start, path, visited)) {
            return path.toArray(new City[0]);
        }
        return new City[0];   // путь не найден
    }

    private boolean findPath(City current, List<City> path, Set<City> visited) {
        path.add(current);
        visited.add(current);

        if (current.equals(end)) {
            return true;
        }
        for (Path p : current.getPaths()) {
            City next = p.destination;

            if (!visited.contains(next)) {
                if (findPath(next, path, visited)) {
                    return true;
                }
            }
        }
        path.removeLast();
        return false;
    }
}
