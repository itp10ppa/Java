package ru.Sukmanova.City;

import java.util.ArrayList;
import java.util.List;


class Path {

    public City destination;
    public int price;

    public Path(City destination, int price) {
        this.destination = destination;
        this.price = price;
    }

    @Override
    public String toString() {
        return destination.getName() + ":" + price;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Path other)) {
            return false;
        }
        return this.price == other.price && this.destination.getName().equals(other.destination.getName());
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(price, destination.getName());
    }
}


public class City {

    private String name;
    private List<Path> paths;

    public City(String name) {
        this.name = name;
        this.paths = new ArrayList<>();
    }

    public City(String name, List<Path> paths) {
        this.name = name;
        this.paths = new ArrayList<>(paths);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Path> getPaths() {
        return paths;
    }

    public void setPath(List<Path> paths) {
        this.paths = paths;
    }

    public void addPath(City other, int price) {
        if (other == this) {
            throw new IllegalArgumentException("Ошибка! Нельзя добавить дорогу в тот же самый город");
        }
        if (price < 0) {
            throw new IllegalArgumentException("Ошибка! Цена не может быть отрицательной");
        }
        for (Path p : paths) {
            if (p.destination.getName().equals(other.getName())) {
                throw new IllegalArgumentException("Ошибка! Дорога в город " + other.getName() + " уже существует!");
            }
        }
        paths.add(new Path(other, price));
    }

    public void removePath(City other) {
        Path removePath = null;

        for (Path p : paths) {
            if (p.destination.getName().equals(other.getName())) {
                removePath = p;
                break;
            }
        }
        if (removePath != null) {
            paths.remove(removePath);
        }
        else {
            System.out.println("Нет пути в " + other.getName());
        }
    }

    @Override
    public String toString() {
        return name + " - " + paths;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof City other)) {
            return false;
        }
        return this.paths.equals(other.paths);
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(paths);
    }
}
