package ru.Sukmanova.City;

import java.util.List;

public class MutualCity extends City {

    public MutualCity(String name) {
        super(name);
    }

    public MutualCity(String name, List<Path> paths) {
        super(name, paths);
    }

    @Override
    public void addPath(City other, int price) {
        super.addPath(other, price);
        other.getPaths().add(new Path(this, price));
    }

    @Override
    public void removePath(City other) {
        super.removePath(other);

        Path reverse = null;
        for (Path p : other.getPaths()) {
            if (p.destination.getName().equals(this.getName())) {
                reverse = p;
                break;
            }
        }
        if (reverse != null) {
            other.getPaths().remove(reverse);
        }
    }
}
